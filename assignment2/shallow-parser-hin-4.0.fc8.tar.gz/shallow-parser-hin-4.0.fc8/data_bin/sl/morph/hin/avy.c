#include "const.h"
#include "../../../../src/sl/morph/hin/analyser/defn.h"
char indword[SIZEOF_IND][AVYWORDSIZE] = {
"!",
"\"",
"$",
"(",
")",
"*",
"+",
",",
"-",
".",
"/",
":",
";",
"?",
"@",
"[",
"]",
"{",
"}",
};
