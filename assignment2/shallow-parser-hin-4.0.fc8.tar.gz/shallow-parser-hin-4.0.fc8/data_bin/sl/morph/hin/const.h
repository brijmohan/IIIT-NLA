#define sizeof_pron_noun_suff 320 
#define SIZEOF_IND 19 
#define SIZEOF_SUFF_ADD 692 
#define TOTAL_FE_INFO  294 
