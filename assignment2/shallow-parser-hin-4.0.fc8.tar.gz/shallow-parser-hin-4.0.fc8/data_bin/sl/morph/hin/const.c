int sizeof_lex = 1 ;
int sizeof_ind = 19 ;
int sizeof_suff_add = 692 ;
int total_fe_info = 294 ;
