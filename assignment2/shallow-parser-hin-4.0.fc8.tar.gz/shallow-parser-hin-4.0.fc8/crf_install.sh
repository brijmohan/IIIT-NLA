cd $SHALLOW_PARSER_HIN/bin/sl/CRF++-0.51
./configure
make clean
make
#su
#make install

